import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import {
  FormGroup,
  FormArray,
  FormBuilder,
  Validators,
  RequiredValidator,
  EmailValidator,
} from '@angular/forms';
import { AllService } from 'src/app/service/all.service';

@Component({
  selector: 'app-form-render',
  templateUrl: './form-render.component.html',
  styleUrls: ['./form-render.component.css'],
})
export class FormRenderComponent implements OnInit {
  renderForm!: FormGroup;
  controlsArray!: FormArray;
  getData: any[] = [];
  controlType: any;
  controlText: any;
  modalName: any;
  currentName: any;
  finalobj: any = {};
  constructor(
    private _all: AllService,
    private fb: FormBuilder,
    private _http: HttpClient
  ) {
    this.controlsArray = new FormArray<FormArray>([]);
  }

  labelArray: any[] = [];

  ngOnInit(): void {
    this._all.arrayData.subscribe({
      next: (data: any) => {
        this.getData = [];
        this.getData = data;
        this.controlType = data?.type;
        this.controlText = data.text;
        this.modalName = data.name;

        // this.getControl(data);
        console.log('data  is array', data);
        this.addControl(data);
      },
    });
    this.controlsArray = new FormArray<FormArray>([]);
    this.renderForm = this.fb.group({
      controls: this.controlsArray,
    });
  }

  getControl(data?: any): FormGroup {
    console.log('get control data', data);
    let obj = {
      type: this.controlType,
      text: this.controlText,
      name: this.modalName,
      valid: data.validation,
    };

    console.log('validations', obj.valid);
    let allValidation: any[] = [];
    obj.valid?.forEach((element: any) => {
      console.log('element is ', element);
      if (element.validation == 'required') {
        allValidation.push(Validators.required);
      }
      if (element.validation == 'email') {
        allValidation.push(Validators.email);
      }
      if (element.validation == 'maxlength') {
        allValidation.push(Validators.maxLength(15));
      }
      if (element.validation == 'minlength') {
        allValidation.push(Validators.minLength(2));
      }
      // let maxlength = element.validation.split(' ');
      // console.log('max is ', maxlength);
      // if (maxlength[0] == 'maxlength') {
      //   allValidation.push(Validators.maxLength(maxlength[1]));
      // }
      // let minlength = element.validation.split(' ');
      // console.log('max is ', minlength);
      // if (minlength[0] == 'minlength') {
      //   allValidation.push(Validators.minLength(minlength[1]));
      // }
    });
    console.log('validators array is ', allValidation);
    this.labelArray.push(obj);
    return this.fb.group({
      newControl: ['', allValidation, ,],
    });

    // return this.
  }

  addControl(data?: any) {
    this.controlsArray.push(this.getControl(data));
    console.log(this.controlsArray);
  }

  getControlFroError(index: number): any {
    return this.controlsArray.at(index).get('newControl');
  }

  setName() {}

  setValue(index: number, controlsArray: any, value: any, name: any) {
    this.finalobj[name] = value;
    console.log('final object is', this.finalobj);
    console.log('forms group is', controlsArray);
    console.log('error control', this.getControlFroError(0));
  }
  removeControl(index: number, data: any) {
    this.controlsArray.removeAt(index);
  }
  afterSubmit: any;
  submit() {
    this._http
      .post('https://winter-summer-sceptre.glitch.me/submit', this.finalobj)
      .subscribe({
        next: (data: any) => {
          console.log(data);
          this.afterSubmit = data?.message;
        },
      });
    console.log(this.renderForm);
    console.log('Render form value', this.finalobj);
  }
}
