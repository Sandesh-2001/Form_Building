import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { AllService } from 'src/app/service/all.service';

@Component({
  selector: 'app-form-builder',
  templateUrl: './form-builder.component.html',
  styleUrls: ['./form-builder.component.css'],
})
export class FormBuilderComponent implements OnInit {
  formsBuilder!: FormGroup;
  validationArray!: FormArray;

  constructor(private fb: FormBuilder, private _all: AllService) {}

  ngOnInit(): void {
    this.validationArray = new FormArray([this.getValid()]);
    this.formsBuilder = this.fb.group({
      text: [''],
      name: [''],
      type: [''],
      validation: this.validationArray,
    });
  }

  getValid(): FormGroup {
    return this.fb.group({
      validation: [''],
    });
  }

  addValid() {
    this.validationArray.push(this.getValid());
  }
  removeValid(i: number) {
    this.validationArray.removeAt(i);
  }
  validArr: any[] = [];
  min: any;
  max: any;
  valid(data: any) {
    let obj = {
      validation: data,
    };
    console.log('checkbox data is', data);
    this.validArr.push(obj);
  }
  addInArray() {
    let allData: any[] = [];
    console.log('form group is ', this.formsBuilder.value);

    this.formsBuilder.value.validation = this.validArr;
    console.log('validegfkjflgjgf', this.formsBuilder.value);
    this._all.addControl(this.formsBuilder.value);
  }
}
